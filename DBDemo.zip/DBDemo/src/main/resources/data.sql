insert into employee values(101,25,'programmer','akhila');
insert into employee values(102,26,'tester','akhi');
insert into employee values(103,27,'admin','sasi');
insert into employee values(104,28,'manager','ramya');
insert into employee values(105,29,'programmer','sruthi');
insert into DEPARTMENT values(11,'ramesh','akhila');
insert into DEPARTMENT values(12,'suresh','mokshita');
insert into DEPARTMENT values(13,'ram','sasi');
